﻿
using CyberSecurityChatBot.CybersScurityChatBot;

namespace CyberSecurityChatbot
{
    internal class TaskStorageHelper
    {
        internal int AddTask(string title, string description, string reminder)
        {
            throw new NotImplementedException();
        }

        internal bool DeleteTask(int id)
        {
            throw new NotImplementedException();
        }

        internal List<CyberTask> LoadTasks()
        {
            throw new NotImplementedException();
        }

        internal bool MarkAsComplete(int id)
        {
            throw new NotImplementedException();
        }
    }
}