﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberSecurityChatBot
    {
        public class ActivityLogger
        {
            private readonly List<string> _logEntries = new List<string>();

            /// <summary>
            /// Logs an action with timestamp
            /// </summary>
            public void Log(string action)
            {
                string entry = $"[{DateTime.Now:HH:mm:ss}] {action}";
                _logEntries.Add(entry);

                // Optional: Keep only last 100 entries to prevent memory growth
                if (_logEntries.Count > 100)
                    _logEntries.RemoveAt(0);
            }

            /// <summary>
            /// Returns the most recent entries (default 10)
            /// </summary>
            public string GetRecentLog(int count = 10)
            {
                if (_logEntries.Count == 0)
                    return "No activities recorded yet.";

                var recent = _logEntries.TakeLast(count).ToList();

                return string.Join("\n", recent.Select((entry, index) =>
                    $"{index + 1}. {entry}"));
            }

            /// <summary>
            /// Returns all log entries
            /// </summary>
            public string GetFullLog()
            {
                if (_logEntries.Count == 0)
                    return "No activities recorded yet.";

                return string.Join("\n", _logEntries.Select((entry, index) =>
                    $"{index + 1}. {entry}"));
            }

            public int GetCount() => _logEntries.Count;

            /// <summary>
            /// Clears all logs
            /// </summary>
            public void Clear()
            {
                _logEntries.Clear();
            }
        }
    }
